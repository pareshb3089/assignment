import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';
import Info from './components/Info';
import Paths from './components/Paths';
import SwaggerUI from "swagger-ui-react"
import "swagger-ui-react/swagger-ui.css"

function App() {
  const [swaggerJson, setSwaggerJson] = useState({});
  const METHODS = [
    'get',
    'post',
    'put',
    'delete',
    'head',
    'options',
    'patch'
  ]

  const getJson = async () => {
    axios
      .get('https://petstore.swagger.io/v2/swagger.json')
      .then((res) => {
        setSwaggerJson(res.data)
        console.log(res.data.tags)
      })
      .catch((err) => console.log(err))
  }

  useEffect(() => {
    getJson()
  }, [])

  return (
    <div>
      {swaggerJson.info &&
        <>
          <div>
            <Info swaggerJson={swaggerJson} />
          </div>
          <div>
            <Paths swaggerJson={swaggerJson} />
            {/* <SwaggerUI spec={swaggerJson}/> */}
          </div>
        </>
      }
    </div>
  );
}

export default App;
